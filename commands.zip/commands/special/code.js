client.on('message', (message) => {
    if (message.content === '!code') {
      const embed = new RichEmbed().setTitle('Use Code').setColor(15844367).setDescription('Use Our Creator Code is: "UnstableRengades" in the Fortnite item shop :)');
      message.channel.send(embed);
    }
  });